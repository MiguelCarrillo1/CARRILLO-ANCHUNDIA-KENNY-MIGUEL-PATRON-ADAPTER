﻿using System;
class Programa
{
    static void Main()
    {
        // Utilizando la clase existente (SensorTemperaturaCelsius) directamente
        SensorTemperaturaCelsius sensorCelsius = new SensorTemperaturaCelsius();
        ClienteTemperatura cliente1 = new ClienteTemperatura(new AdaptadorCelsiusAFahrenheit(sensorCelsius));
        cliente1.MostrarTemperatura();

        // Simulando un error al adaptar la temperatura
        ITemperaturaProveedor adaptador = new AdaptadorCelsiusAFahrenheit(null);
        ClienteTemperatura cliente2 = new ClienteTemperatura(adaptador);
        cliente2.MostrarTemperatura();
    }
}
