// Clase existente (Adaptado)
public class SensorTemperaturaCelsius
{
    public double ObtenerTemperaturaEnCelsius()
    {
        // Lógica para obtener la temperatura en grados Celsius
        return 25.0;
    }
}
//  SensorTemperaturaCelsius es la clase existente que tiene un método 
//  ObtenerTemperaturaEnCelsius() que proporciona la temperatura en grados Celsius.