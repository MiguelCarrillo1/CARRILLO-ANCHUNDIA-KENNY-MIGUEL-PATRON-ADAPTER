// Cliente
public class ClienteTemperatura
{
    private readonly ITemperaturaProveedor proveedorTemperatura;

    public ClienteTemperatura(ITemperaturaProveedor proveedorTemperatura)
    {
        this.proveedorTemperatura = proveedorTemperatura;
    }

    public void MostrarTemperatura()
    {
        double temperatura;
        if (IntentarObtenerTemperatura(out temperatura))
        {
            Console.WriteLine($"Temperatura: {temperatura} Fahrenheit");
        }
        else
        {
            Console.WriteLine("Error al obtener la temperatura.");
        }
    }

    private bool IntentarObtenerTemperatura(out double temperatura)
    {
        try
        {
            temperatura = proveedorTemperatura.ObtenerTemperatura();
            return true;
        }
        catch
        {
            temperatura = 0.0;
            return false;
        }
    }
}
//  ClienteTemperatura es el cliente que espera la interfaz ITemperaturaProveedor
//  y utiliza el método MostrarTemperatura() para mostrar la temperatura en grados Fahrenheit.