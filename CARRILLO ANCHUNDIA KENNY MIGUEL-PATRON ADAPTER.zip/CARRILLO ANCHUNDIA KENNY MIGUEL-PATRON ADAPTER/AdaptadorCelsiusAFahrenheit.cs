// Adaptador
public class AdaptadorCelsiusAFahrenheit : ITemperaturaProveedor
{
    private readonly SensorTemperaturaCelsius sensorCelsius;

    public AdaptadorCelsiusAFahrenheit(SensorTemperaturaCelsius sensorCelsius)
    {
        this.sensorCelsius = sensorCelsius;
    }

    public double ObtenerTemperatura()
    {
        // Intento de adaptar la temperatura de Celsius a Fahrenheit
        try
        {
            if (sensorCelsius == null)
            {
                throw new ArgumentNullException(nameof(sensorCelsius), "El objeto SensorTemperaturaCelsius no puede ser nulo.");
            }

            double temperaturaCelsius = sensorCelsius.ObtenerTemperaturaEnCelsius();
            double temperaturaFahrenheit = (temperaturaCelsius * 9 / 5) + 32;

            // Indicador de éxito
            Console.WriteLine("Adaptación exitosa.");

            return temperaturaFahrenheit;
        }
        catch (Exception ex)
        {
            // Indicador de error
            Console.WriteLine($"Error al adaptar la temperatura");

            // Propagar la excepción
            throw;
        }
    }
}
//  AdaptadorCelsiusAFahrenheit es el adaptador que implementa la interfaz 
//  ITemperaturaProveedor y utiliza la clase SensorTemperaturaCelsius para 
//  adaptar la temperatura de Celsius a Fahrenheit.