// Interfaz Objetivo
public interface ITemperaturaProveedor
{
    double ObtenerTemperatura();
}
//  Esta interfaz define el método ObtenerTemperatura(), 
//  que representa la interfaz objetivo que el cliente espera.